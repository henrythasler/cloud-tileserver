"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pg_1 = require("pg");
const client = new pg_1.Client({
    host: 'osmdata.ckcf9lcriark.eu-central-1.rds.amazonaws.com',
    port: 5432,
    user: 'postgres',
    password: '7QF=2Xh$vnQ+t7n',
});
exports.handler = async (event, context) => {
    await client.connect();
    //let res = await client.query("SELECT pg_size_pretty(pg_database_size('local')) as db_size;")
    // console.log(`res=${res}`);
    console.log(`getRemainingTimeInMillis=${context.getRemainingTimeInMillis()}`);
    let response = JSON.stringify(event, null, 2);
    return Promise.resolve(response);
};
